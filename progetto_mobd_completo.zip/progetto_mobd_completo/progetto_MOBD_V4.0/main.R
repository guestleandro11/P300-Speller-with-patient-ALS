#IL RISULTATO MIGLIORE È STATO OTTENUTO USANDO UNA SVM LINEARE
#DOVE PRENDO L'ELEMENTO +1 A DISTANZA MAGGIORE DALL'IPERPIANO

#leggere il file "readme.txt" per la guida all'utilizzo durante la fase di valutazione della professoressa

set.seed(123)

#importazione librerie
library("LiblineaR")
library("CORElearn")
library("dplyr")
library("e1071")

#importazione funzioni
source("cambio_nomiX.R")
source("cambio_nomiY.R")
source("cambio_nomiC.R")
source("data_understanding.R")
source("split.R")
source("data_normalization.R")
source("choosing_classifier.R")
source("setting_linear_SVM.R")
source("linear_SVM.R")
source("polinomial_SVM.R")
source("gaussian_SVM.R")
source("opt_classifier.R")
source("data_media_righe.R")
source("test_accuratezza.R")
source("calcolo_accuratezza.R")
#------------------------------------------GET_DATA-------------------------------------------#

#percorso corrente
my_dir <- getwd()

#IMPOSTARE 1 ANZICHÈ NULL SE SIAMO IN FASE DI VALUTAZIONE CON IL TEST SET DELLA PROFESSORESSA
testSet_prof <- NULL

#Usato per training
X <- "X.txt"
Y <- "Y.txt"
C <- "C.txt"

#Leggo il mio Dataset, cioè leggo i 3 file X, Y, C rinomino il nome delle colonne per leggibilità
dataX <- read.table(X, quote="\"", comment.char="")
dataX <- cambio_nomiX(dataX)

dataY <- read.table(Y, quote="\"", comment.char="")
dataY <- cambio_nomiY(dataY)

dataC <- read.table(C, quote="\"", comment.char="")
dataC <- cambio_nomiC(dataC)

data <- cbind(dataC,dataX, dataY) 


#QUI AL POSTO DI NULL BISOGNA METTERE I NOMI DEI 3 FILE DELLA PROFESSORESSA
X_prof <- NULL
Y_prof <- NULL
C_prof <- NULL

#Se diverso da NULL -->sto valutando con un testSet-->leggo testSetEsame
if( !is.null(testSet_prof) ){
  testSetEsame_X <- read.table(X_prof, quote="\"", comment.char="")
  testSetEsame_X <- cambio_nomiX(testSetEsame_X)
  
  testSetEsame_Y <- read.table(Y_prof, quote="\"", comment.char="")
  testSetEsame_Y<- cambio_nomiY(testSetEsame_Y)
  
  testSetEsame_C <- read.table(C_prof, quote="\"", comment.char="")
  testSetEsame_C <- cambio_nomiC(testSetEsame_C)
  
  #ora questo è il testset dell'esame in forma compatta
  testSetEsame <- cbind(testSetEsame_C, testSetEsame_X, testSetEsame_Y)
}


#--------------------------------------MANIPOLAZIONE_DATASET------------------------------------#
#ADESSO VADO A MANIPOLARE SIA IL MIO DATASET CHE L TESTSET DELLA PROFESSORESSA IN QUESTO MODO:
#DELLE 10 ITERAZIONI A CARATTERE FACCIO LA MEDIA ARITMETICA QUINDI OTTENGO UN DATASET NUOVO COMPOSTO
#DA ESATTAMENTE 360 RIGHE ANZICHE 3600. DOVE LE PRIME 12 RIGHE RIGUARDANO I FLASH RIGA/COLONNA DEL PRIMO
#CARATTERE LE SUCCESSIVE 12 RIGHE I FLASH RIGA/COLONNA DEL SECONDO CARATTERE ECC
#INOLTRE LA FUNZIONE "data_media_righe" MI METTE IN ORDINE DA 1 A 12 I VALORI DI OGNI FLASH PER CARATTERE

data_mediato <- data_media_righe(data)
data_mediato <- as.data.frame(data_mediato) #dataframe
#posso togliere adesso la prima colonna del dataset che indica la riga/colonna che si illumina (in ordine da 1 a 12)
data_mediato$V1 <- NULL

#ANCHE PER IL TEST SET DELLA PROFESSORESSA DEVO FARE LA STESSA IDENTICA COSA
if( !is.null(testSet_prof) ){
  test_set_mediato_prof <- data_media_righe(testSetEsame)
  test_set_mediato_prof <- as.data.frame(test_set_mediato_prof)
  test_set_mediato_prof$V1 <- NULL
}


#----------------------------------------DATA_UNDERSTANDING----------------------------------------#
#ho una percentuale molto piccola di outliers(sotto lo 0.01%) quidi non mi è sembrato rilevante gestire gli outlier
data_summary <- data_understanding(my_data = data_mediato)
outlier <- data_summary$`Lista degli outliers`

#-----------------------------------SPLIT_&_DATA_NORMALIZATION-------------------------------------#
#LO SPLIT DEL MIO DATASET È COMOSTO IN QUESTO MODO: 4 PAROLE COME TRAININING-SET E 2 PAROLE COME
#TEST SET

#uso questa variabile per capire se sto valutando il testset all'interno dello split
#oppure è quello dato dalla professoressa
isTestSet <- 0

if(!is.null(testSet_prof)){
  isTestSet <- 1 #quindi se valuto il testset della professoressa isTestSet = 1
  
}

my_split <- split(data_mediato, isTestSet, test_set_mediato_prof)

#normalizzo, e creo una lista contenente 4 elementi che sono: scaled_training, label_train, sacaled_test e label_test
normalized_split <- data_normalization(my_split)


#------------------------------------TRAINING_ESEGUIRE_SOLO_IN_FASE_DI_TEST_NON_IN_VALUTAZIONE-----------------------------------------#
#in letteratura ci sono diversi paper che riguardano questo argomento. La maggior parte di loro 
#utilizza una svm lineare o gaussiana. Nel mio caso una svm lineare è stata la miglior scelta in termini
#di accuratezza

#cross_validation

trainSetSelection <- as.data.frame(normalized_split$scaled_training)
targetTrainSet <- as.data.frame(normalized_split$label_train)
appoggio <- matrix(0, nrow = 240, ncol = 1)
appoggio <- as.data.frame(appoggio)
targetTrainSet <- cbind(targetTrainSet, appoggio)

#Questa parte eseguita solo in fase di training-->non in sede di valutazione
if(is.null(testSet_prof)){
  cross_validation_output <- choosing_classifier(trainSetSelection,targetTrainSet) 
  cross_validation_output
  }

#come dicono vari articoli riguardo questo argomento, la svm lineare risulta la migliore quando ho il dataset manipolato come ho fatto io
#cioè ho considerato la media delle 10 iterazioni a carattere infatti nel modello svm lineare vado a prendere il punto a distanza maggiore
#dall'iperpiano ottimo e quello sarà classificato come +1
c_setting <-setting_linear_SVM(trainSetSelection,targetTrainSet)
c_setting

#adesso valutiamo per la svm lineare quale è il miglior C

#quindi a conti fatti i risultati cambiando la C sono pressochè identici. Allora utilizzerò C = 1

#------------------------------------------------------VALUTAZIONE--------------------------------------------------#


#IN LETTERATURA IL CLASSIFICATORE MIGLIORE È QUELLO LINEARE
#test_result è una lista contenente le etichette predette dalla svm lineare, ora però devo prendere per ogni sestupla
#quindi per ogni sestupla di flash riga o colonna l'elemento a distanza più grande dall'iperpiano e settarlo a +1 e settare
#gli eventuali altri elementi che sono anche loro a +1 a -1. Tutto questo lo faccio dentro la funzione calcolo_accuratezza
test_result <- opt_classifier(normalized_split$scaled_training,normalized_split$label_train,normalized_split$scaled_test,normalized_split$label_test)

accuratezza <- calcolo_accuratezza(test_result, normalized_split$label_test)
accuratezza #in termini di percentuale


