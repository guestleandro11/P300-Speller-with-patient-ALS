test_accuratezza <- function(result, label_test, n_parole){
  #conto quanti caratteri ho preso correttamente
  #magari questo blocco di codice mettilo in una funzione...
  count_success <- 0 #contatore del numero di caratteri giusti
  c <- 0 #ogni volta che in 12 iterazioni trova 2 flash corretti significa che ho individuato il carattere giusto
  temp <- 0
  k <- 0
  a <- 0
  p <- 0
  flash <- n_parole*5*12
  for (j in 1:flash) { #in totale ho esattamente 1 flash mediato per ogni carattere che si ripete e ho esattamente 
                    #2 parole nel testset cioè 10 caratteri totali e cioè 120 flash totali (12 flash a carattere)
    
    k <- k+1
    
    if(result[j,1] == 1 & result[j,1] == label_test[j,1]){
        c <- c+1
        if(c==2 & temp == 0){ #ho trovato i due flash giusti che mi danno il carattere giusto
          temp <- 1
          count_success <- count_success + 1 #mi dice il numero totale di caratteri che ho trovato 
        }
    }
    if(result[j,1] != label_test[j,1] & c < 2){
      temp <- 1
    }
    
    if(result[j,1] != label_test[j,1] & c == 2 & p == 0){ #quindi temp = 1, mi serve un'altra variabile qui dentro, la chiamo p
      p <- 1                                              #in modo tale che se trova ad esempio 3 o più elementi di cui 2 flash giusti
      count_success <- count_success - 1                  #ed 1 o più flash errati allora diminuisce solo una volta count_success
    }
    
  
    if(k == 12){
      c <- 0
      temp <- 0
      k <- 0
    }

  }
  caratteri <- n_parole * 5
  accuratezza <- (count_success/caratteri)*100
  #atteno quando lavoro con il test set della professoressa hai solo 5 cartatteri
return(accuratezza)
  
  
}