#TR=dati di training
#YTR=classe dati di training
#TS=dati di test
#YTS=classe dati di test
#questo classificatore si trova nel package LibLineaR
opt_classifier <- function(TR,YTR,TS,YTS){
  set.seed(123)
  #addestramento utilizzando la migliore c individuata mediante cross validation
  linear_model<-LiblineaR(data=TR,target=YTR,type=1,cost=1,bias=TRUE,verbose=FALSE) #
  #predizione sui dati di test
  test_prediction <- predict(linear_model,TS,decisionValues = TRUE)
 
  return(test_prediction)
}