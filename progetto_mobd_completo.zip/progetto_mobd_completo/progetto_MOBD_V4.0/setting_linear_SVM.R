setting_linear_SVM <- function(trainSetTemp, targetTrainTemp){
  set.seed(123)
  c_vector <- c(10, 1, 0.1)
  
  
  block_A <- trainSetTemp[c(1:60),]
  label_A <- targetTrainTemp[c(1:60),]
  
  block_B <- trainSetTemp[c(61:120),]
  label_B <- targetTrainTemp[c(61:120),]
  
  block_C <- trainSetTemp[c(121:180),]
  label_C <- targetTrainTemp[c(121:180),]
  
  block_D <- trainSetTemp[c(181:240),]
  label_D <- targetTrainTemp[c(181:240),]
  
  #------------------------------------------------------CROSS_VALIDATION------------------------------------#
  train_1 <- rbind(block_A, block_B, block_C)
  label_train_1 <- rbind(label_A, label_B, label_C)
  label_train_1$V1 <- NULL
  validation_test_1 <- block_D
  label_validation_1 <- label_D 
  
  
  train_2 <- rbind(block_A, block_B, block_D)
  label_train_2 <- rbind(label_A, label_B, label_D)
  label_train_2$V1 <- NULL
  validation_test_2 <- block_C
  label_validation_2 <- label_C
  
  
  train_3 <- rbind(block_A, block_C, block_D)
  label_train_3 <- rbind(label_A, label_C, label_D)
  label_train_3$V1 <- NULL
  validation_test_3 <- block_B
  label_validation_3 <- label_B
  
  
  train_4 <- rbind(block_B, block_C, block_D)
  label_train_4 <- rbind(label_B, label_C, label_D)
  label_train_4$V1 <- NULL
  validation_test_4 <- block_A
  label_validation_4 <- label_A
  
  
  #--------------------------------------------------LINEAR_SVM_10-------------------------------------------#
  
  c10 <- c_vector[1]
  
  #addestramento utilizzando la migliore c individuata mediante cross validation
  linear_model_1 <- LiblineaR(data=train_1,target=label_train_1,type=1,cost=c10,bias=TRUE,verbose=FALSE) #
  #predizione sui dati di test
  test_prediction_1 <- predict(linear_model_1,validation_test_1,decisionValues = TRUE)
  #prendo il punto a distanza massima dall'iperpiano
  accuratezza_1 <- calcolo_accuratezza(test_prediction_1, label_validation_1)
  
  linear_model_2 <- LiblineaR(data=train_2,target=label_train_2,type=1,cost=c10,bias=TRUE,verbose=FALSE) #
  #predizione sui dati di test
  test_prediction_2 <- predict(linear_model_2,validation_test_2,decisionValues = TRUE)
  #prendo il punto a distanza massima dall'iperpiano
  accuratezza_2 <- calcolo_accuratezza(test_prediction_2, label_validation_2)
  
  linear_model_3 <- LiblineaR(data=train_3,target=label_train_3,type=1,cost=c10,bias=TRUE,verbose=FALSE) #
  #predizione sui dati di test
  test_prediction_3 <- predict(linear_model_3,validation_test_3,decisionValues = TRUE)
  #prendo il punto a distanza massima dall'iperpiano
  accuratezza_3 <- calcolo_accuratezza(test_prediction_3, label_validation_3)
  
  linear_model_4 <- LiblineaR(data=train_4,target=label_train_4,type=1,cost=c10,bias=TRUE,verbose=FALSE) #
  #predizione sui dati di test
  test_prediction_4 <- predict(linear_model_4,validation_test_4,decisionValues = TRUE)
  #prendo il punto a distanza massima dall'iperpiano
  accuratezza_4 <- calcolo_accuratezza(test_prediction_4, label_validation_4)
  
  media_linearSVM10 <- mean(accuratezza_1,accuratezza_2,accuratezza_3,accuratezza_4)
  
  
  #--------------------------------------------------LINEAR_SVM_1-------------------------------------------#
  
  c1 <- c_vector[2]
  
  #addestramento utilizzando la migliore c individuata mediante cross validation
  linear_model_1 <- LiblineaR(data=train_1,target=label_train_1,type=1,cost=c1,bias=TRUE,verbose=FALSE) #
  #predizione sui dati di test
  test_prediction_1 <- predict(linear_model_1,validation_test_1,decisionValues = TRUE)
  #prendo il punto a distanza massima dall'iperpiano
  accuratezza_1 <- calcolo_accuratezza(test_prediction_1, label_validation_1)
  
  linear_model_2 <- LiblineaR(data=train_2,target=label_train_2,type=1,cost=c1,bias=TRUE,verbose=FALSE) #
  #predizione sui dati di test
  test_prediction_2 <- predict(linear_model_2,validation_test_2,decisionValues = TRUE)
  #prendo il punto a distanza massima dall'iperpiano
  accuratezza_2 <- calcolo_accuratezza(test_prediction_2, label_validation_2)
  
  linear_model_3 <- LiblineaR(data=train_3,target=label_train_3,type=1,cost=c1,bias=TRUE,verbose=FALSE) #
  #predizione sui dati di test
  test_prediction_3 <- predict(linear_model_3,validation_test_3,decisionValues = TRUE)
  #prendo il punto a distanza massima dall'iperpiano
  accuratezza_3 <- calcolo_accuratezza(test_prediction_3, label_validation_3)
  
  linear_model_4 <- LiblineaR(data=train_4,target=label_train_4,type=1,cost=c1,bias=TRUE,verbose=FALSE) #
  #predizione sui dati di test
  test_prediction_4 <- predict(linear_model_4,validation_test_4,decisionValues = TRUE)
  #prendo il punto a distanza massima dall'iperpiano
  accuratezza_4 <- calcolo_accuratezza(test_prediction_4, label_validation_4)
  
  media_linearSVM1 <- mean(accuratezza_1,accuratezza_2,accuratezza_3,accuratezza_4)
  
  
  #--------------------------------------------------LINEAR_SVM_0.1-------------------------------------------#
  
  c01 <- c_vector[3]
  
  #addestramento utilizzando la migliore c individuata mediante cross validation
  linear_model_1 <- LiblineaR(data=train_1,target=label_train_1,type=1,cost=c01,bias=TRUE,verbose=FALSE) #
  #predizione sui dati di test
  test_prediction_1 <- predict(linear_model_1,validation_test_1,decisionValues = TRUE)
  #prendo il punto a distanza massima dall'iperpiano
  accuratezza_1 <- calcolo_accuratezza(test_prediction_1, label_validation_1)
  
  linear_model_2 <- LiblineaR(data=train_2,target=label_train_2,type=1,cost=c01,bias=TRUE,verbose=FALSE) #
  #predizione sui dati di test
  test_prediction_2 <- predict(linear_model_2,validation_test_2,decisionValues = TRUE)
  #prendo il punto a distanza massima dall'iperpiano
  accuratezza_2 <- calcolo_accuratezza(test_prediction_2, label_validation_2)
  
  linear_model_3 <- LiblineaR(data=train_3,target=label_train_3,type=1,cost=c01,bias=TRUE,verbose=FALSE) #
  #predizione sui dati di test
  test_prediction_3 <- predict(linear_model_3,validation_test_3,decisionValues = TRUE)
  #prendo il punto a distanza massima dall'iperpiano
  accuratezza_3 <- calcolo_accuratezza(test_prediction_3, label_validation_3)
  
  linear_model_4 <- LiblineaR(data=train_4,target=label_train_4,type=1,cost=c01,bias=TRUE,verbose=FALSE) #
  #predizione sui dati di test
  test_prediction_4 <- predict(linear_model_4,validation_test_4,decisionValues = TRUE)
  #prendo il punto a distanza massima dall'iperpiano
  accuratezza_4 <- calcolo_accuratezza(test_prediction_4, label_validation_4)
  
  media_linearSVM01 <- mean(accuratezza_1,accuratezza_2,accuratezza_3,accuratezza_4)
  

  #------------------------------------------------RAGGRUPPO------------------------------------------------#
  
  risultati <- list(media_linearSVM10, media_linearSVM1, media_linearSVM01)
  
  names(risultati) <- c("C=10", "C=1", "C=0.1")
  
  

  return(risultati)
  
}
