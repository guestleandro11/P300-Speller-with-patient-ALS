choosing_classifier <- function(trainSetTemp,targetTrainTemp){
  set.seed(123)
  #Indiividuiamo il miglior classficiatore
  
  #prima di tutto divido il mio trainingset in 4 blocchi dove ogni blocco contiene una parola
  #in tal modo posso considerare un blocco come validation
  
  block_A <- trainSetTemp[c(1:60),]
  label_A <- targetTrainTemp[c(1:60),]
  
  block_B <- trainSetTemp[c(61:120),]
  label_B <- targetTrainTemp[c(61:120),]
  
  block_C <- trainSetTemp[c(121:180),]
  label_C <- targetTrainTemp[c(121:180),]
  
  block_D <- trainSetTemp[c(181:240),]
  label_D <- targetTrainTemp[c(181:240),]
#------------------------------------------------------CROSS_VALIDATION----------------------------------#
  train_1 <- rbind(block_A, block_B, block_C)
  label_train_1 <- rbind(label_A, label_B, label_C)
  label_train_1$V1 <- NULL
  validation_test_1 <- block_D
  label_validation_1 <- label_D 
  
  
  train_2 <- rbind(block_A, block_B, block_D)
  label_train_2 <- rbind(label_A, label_B, label_D)
  label_train_2$V1 <- NULL
  validation_test_2 <- block_C
  label_validation_2 <- label_C
  
  
  train_3 <- rbind(block_A, block_C, block_D)
  label_train_3 <- rbind(label_A, label_C, label_D)
  label_train_3$V1 <- NULL
  validation_test_3 <- block_B
  label_validation_3 <- label_B
  
  
  train_4 <- rbind(block_B, block_C, block_D)
  label_train_4 <- rbind(label_B, label_C, label_D)
  label_train_4$V1 <- NULL
  validation_test_4 <- block_A
  label_validation_4 <- label_A

  #--------------------------------------------------LINEAR_SVM-------------------------------------------#
  
  #addestramento utilizzando la migliore c individuata mediante cross validation
  linear_model_1 <- LiblineaR(data=train_1,target=label_train_1,type=1,cost=1,bias=TRUE,verbose=FALSE) #
  #predizione sui dati di test
  test_prediction_1 <- predict(linear_model_1,validation_test_1,decisionValues = TRUE)
  #prendo il punto a distanza massima dall'iperpiano
  accuratezza_1 <- calcolo_accuratezza(test_prediction_1, label_validation_1)
  
  linear_model_2 <- LiblineaR(data=train_2,target=label_train_2,type=1,cost=1,bias=TRUE,verbose=FALSE) #
  #predizione sui dati di test
  test_prediction_2 <- predict(linear_model_2,validation_test_2,decisionValues = TRUE)
  #prendo il punto a distanza massima dall'iperpiano
  accuratezza_2 <- calcolo_accuratezza(test_prediction_2, label_validation_2)
  
  linear_model_3 <- LiblineaR(data=train_3,target=label_train_3,type=1,cost=1,bias=TRUE,verbose=FALSE) #
  #predizione sui dati di test
  test_prediction_3 <- predict(linear_model_3,validation_test_3,decisionValues = TRUE)
  #prendo il punto a distanza massima dall'iperpiano
  accuratezza_3 <- calcolo_accuratezza(test_prediction_3, label_validation_3)
  
  linear_model_4 <- LiblineaR(data=train_4,target=label_train_4,type=1,cost=1,bias=TRUE,verbose=FALSE) #
  #predizione sui dati di test
  test_prediction_4 <- predict(linear_model_4,validation_test_4,decisionValues = TRUE)
  #prendo il punto a distanza massima dall'iperpiano
  accuratezza_4 <- calcolo_accuratezza(test_prediction_4, label_validation_4)
  
  
  media_linearSVM <- mean(accuratezza_1,accuratezza_2,accuratezza_3,accuratezza_4)
  
  #--------------------------------------------------GAUSSIAN_SVM-------------------------------------------#
  
  gauss_model_1 <- svm(x=train_1,y=label_train_1,scale=F,type="C-classification",kernel = "radial") #
  #predizione sui dati di test
  gauss_test_prediction_1 <- predict(gauss_model_1,validation_test_1)
  gauss_test_prediction_1 <- as.data.frame(gauss_test_prediction_1)
  gauss_accuratezza_1 <- test_accuratezza(gauss_test_prediction_1, label_validation_1, 1) #devo specificare anche il numero di parole del validation set
  
  gauss_model_2 <- svm(x=train_2,y=label_train_2,scale=F,type="C-classification",kernel = "radial") #
  #predizione sui dati di test
  gauss_test_prediction_2 <- predict(gauss_model_2,validation_test_2)
  gauss_test_prediction_2 <- as.data.frame(gauss_test_prediction_2)
  gauss_accuratezza_2 <- test_accuratezza(gauss_test_prediction_2, label_validation_2, 1) #devo specificare anche il numero di parole del validation set
  
  gauss_model_3 <- svm(x=train_3,y=label_train_3,scale=F,type="C-classification",kernel = "radial") #
  #predizione sui dati di test
  gauss_test_prediction_3 <- predict(gauss_model_3,validation_test_3)
  gauss_test_prediction_3 <- as.data.frame(gauss_test_prediction_3)
  gauss_accuratezza_3 <- test_accuratezza(gauss_test_prediction_3, label_validation_3, 1) #devo specificare anche il numero di parole del validation set
  
  gauss_model_4 <- svm(x=train_4,y=label_train_4,scale=F,type="C-classification",kernel = "radial") #
  #predizione sui dati di test
  gauss_test_prediction_4 <- predict(gauss_model_4,validation_test_4)
  gauss_test_prediction_4 <- as.data.frame(gauss_test_prediction_4)
  gauss_accuratezza_4 <- test_accuratezza(gauss_test_prediction_4, label_validation_4, 1) #devo specificare anche il numero di parole del validation set
  
  
  media_gaussSVM <- mean(gauss_accuratezza_1,gauss_accuratezza_2,gauss_accuratezza_3,gauss_accuratezza_4)
  
  
  #--------------------------------------------------POLINOMIAL_SVM-------------------------------------------#
  
  polinomial_model_1<-svm(x=train_1,y=label_train_1,scale=F,type="C-classification",kernel="polynomial") #
  polinomial_test_prediction_1 <- predict(polinomial_model_1,validation_test_1)
  polinomial_test_prediction_1 <- as.data.frame(polinomial_test_prediction_1)
  polinomial_accuratezza_1 <- test_accuratezza(polinomial_test_prediction_1, label_validation_1, 1) #devo specificare anche il numero di parole del validation set
  
  polinomial_model_2<-svm(x=train_2,y=label_train_2,scale=F,type="C-classification",kernel="polynomial") #
  polinomial_test_prediction_2 <- predict(polinomial_model_2,validation_test_2)
  polinomial_test_prediction_2 <- as.data.frame(polinomial_test_prediction_2)
  polinomial_accuratezza_2 <- test_accuratezza(polinomial_test_prediction_2, label_validation_2, 1) #devo specificare anche il numero di parole del validation set
  
  polinomial_model_3<-svm(x=train_3,y=label_train_3,scale=F,type="C-classification",kernel="polynomial") #
  polinomial_test_prediction_3 <- predict(polinomial_model_3,validation_test_3)
  polinomial_test_prediction_3 <- as.data.frame(polinomial_test_prediction_3)
  polinomial_accuratezza_3 <- test_accuratezza(polinomial_test_prediction_3, label_validation_3, 1) #devo specificare anche il numero di parole del validation set
  
  polinomial_model_4<-svm(x=train_4,y=label_train_4,scale=F,type="C-classification",kernel="polynomial") #
  polinomial_test_prediction_4 <- predict(polinomial_model_4,validation_test_4)
  polinomial_test_prediction_4 <- as.data.frame(polinomial_test_prediction_4)
  polinomial_accuratezza_4 <- test_accuratezza(polinomial_test_prediction_4, label_validation_4, 1) #devo specificare anche il numero di parole del validation set
  
  media_polinomialSVM <- mean(polinomial_accuratezza_1, polinomial_accuratezza_2, polinomial_accuratezza_3, polinomial_accuratezza_4)
  
  #------------------------------------------------RAGGRUPPO_I_RISULTATI_MEDI------------------------------------#
  
  media_svm <- list(media_linearSVM, media_gaussSVM, media_polinomialSVM)
  names(media_svm) <- c("media_svm_lineare_max", "media_svm_gaussiana", "media_polinomiale")
  return(media_svm)
}