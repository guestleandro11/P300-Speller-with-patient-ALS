cambio_nomiX <- function(X){

  number_of_column <- ncol(X) 
  
  for(i in 1 : number_of_column){
    temp_name <- paste("X", i, sep = "")
    names(X)[i] <- c(temp_name)
    
  }
  
  return(X)
}