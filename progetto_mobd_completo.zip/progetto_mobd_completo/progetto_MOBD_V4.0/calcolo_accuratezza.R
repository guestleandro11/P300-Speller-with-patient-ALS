calcolo_accuratezza <- function(test_result, label_vere){
  
  manipolazione_valori <- test_result$predictions
  manipolazione_valori_data <- as.data.frame(manipolazione_valori)
  
  manipolazione_distanza <- test_result$decisionValues
  manipolazione_distanza_data <- as.data.frame(manipolazione_distanza)
  
  righe <- nrow(manipolazione_valori_data)
  caratteri <- righe/12
  parole <- caratteri/5
  flash <- caratteri * 2
  
  indici <- matrix(0, nrow = righe, ncol = 1)
  
  for(i in 1:righe){
    indici[i,] <- i
  }
  indici <- as.data.frame(indici)
  
  label_definitivo <- cbind(indici,manipolazione_distanza_data)
  
  #adesso il trucco è ragionare in sestuple e per ogni sestupla prendi il valore massimo che sarà memorizzato in un 
  #vettore di appoggio dove però vado ad inserire il valore dell'indice corrispondente
  indici_massimi <- matrix(0, nrow = flash, ncol = 1)
  
  #temp <- matrix(0, nrow = 6, ncol = 1)
  k <- 1
  j <- 6
  
  for(i in 1:flash){
    temp <- label_definitivo[k:j,]
    max_index <- which.max(temp$`1`)
    indici_massimi[i,1] <- temp[max_index, 1]#cioè cosi seleziono l'elemento più grande della sestupla e memorizzo il suo indice (da 1 a 120)
    k <- k + 6
    j <- j + 6 
    
  }
  temp <- as.data.frame(temp)
  #vettore_app <- matrix(0, nrow = 6, ncol = 1) #dove inserisco tutti i valori delle sestuple righe o colonne flashate
  
  indici_massimi <- as.data.frame(indici_massimi)
  risultato <-test_result$predictions #è sempre il risultato che ottengo dalla SVM ma adesso devo seleionare i +1 massimi e mettere 
  #i +1 non massimi a -1
  
  for (i in 1:righe){
    risultato[i] <- -1
  }
  
  for(i in 1 : flash){
    j <- indici_massimi[i,1]
    risultato[j] <- 1
  }
  
  risultato <- as.data.frame(risultato)
  
  #label_test <- normalized_split[["label_test"]]
  #label_test <- as.data.frame(label_test)
  
  label_test <- label_vere
  label_test <- as.data.frame(label_test)
  accuratezza_test <- test_accuratezza(risultato, label_test, parole) 
  
  
  return(accuratezza_test)
  
  
}