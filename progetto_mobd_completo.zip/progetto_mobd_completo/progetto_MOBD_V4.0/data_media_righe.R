data_media_righe <- function(my_data){
  set.seed(123)
  #le matrici le inizializzo a 0
  righe_dataset <- nrow(my_data)
  
  caratteri_tot <- (righe_dataset/12)/10 #ho in totale questi caratteri
  righe_totali <- righe_dataset/10 #cioè adesso non ho più 10 iterazioni a carattere ma solo 1 che è dta dalla media delle 10 iterazioni
  
  blocco <- matrix(0, nrow = 120 , ncol = 1634) #creo una matrice di appoggio per calcolare la media (per ogni carattere ho 120 righe e
                                                #1634 colonne incluso label e identificativo riga/colonna)
  
  dataset_mediato <- matrix(0, nrow = righe_totali, ncol = 1634) #360 righe perch? ho 30 caratteri *12 cambi di riga/colonna per carattere
  x <- 1
  y <- 1
  
  for(i in 1:caratteri_tot){ #una lettera alla volta
    blocco <- my_data[(c(x:(i*120))), ]#blocco contiene esattamente le prime 120 righe che corrispondono a 10 iterazioni della stessa lettera
    #ora devo fare la media dei valori uguali nel blocco, ho esattamente 12 righe/colonne diverse
    for (j in 1:12) {
      m <- blocco[blocco$CR == j, ] #matrice di 10 colonne e 10 righe con STESSA LABEL j che va da 1 a 12
      w <- colMeans(m)#conviene che faccio la media anche dell'etichetta poi al limite la converto in intero idem per i valori di CR 
      dataset_mediato[y,] <- w
      y <- y + 1
    }
    x <- (120*i)+1
  }
  
  
  
  
  return(dataset_mediato)
}
