split <- function(my_data, isTestSet, test_prof){
  set.seed(123)
  #faccio uno split del dataset supervisionato prendendo esattamente 4 parole
  training_set <- my_data[c(1:240),]
  
  #uso come test le mie 2 parole del dataset
  if(isTestSet == 0){
    test_set <- my_data[c(241:360),]
  }
  
  #uso come test la parola della professoressa
  if(isTestSet == 1){
    test_set <- test_prof
  }
  
  
  data_split <- list(training_set, test_set)
  names(data_split) <- c("training_set", "test_set")
  
  return(data_split)
}