cambio_nomiC <- function(C){

    names(C)[1] <- "CR"

  return(C)
}