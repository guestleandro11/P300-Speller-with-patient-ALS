#TR=dati di training
#YTR=classe dati di training
#TS=dati di test
#YTS=classe dati di test
#questo classificatore si trova nel package LibLineaR
linear_SVM <- function(TR,YTR,TS,YTS){
  set.seed(123)
  #addestramento
  linear_model<-LiblineaR(data=TR,target=YTR,type=1,cost=1,bias=TRUE,verbose=FALSE) #
  #predizione sui dati di test
  test_prediction <- predict(linear_model,TS,decisionValues = TRUE)
  
  manipolazione_valori <- test_prediction$predictions
  manipolazione_valori_data <- as.data.frame(manipolazione_valori) #per comodità
  
  manipolazione_distanza <- test_prediction$decisionValues
  manipolazione_distanza_data <- as.data.frame(manipolazione_distanza)
  
  righe <- nrow(manipolazione_distanza_data)
  caratteri <- righe/12
  parole <- caratteri/5
  flash <- caratteri * 2
  
  indici <- matrix(0, nrow = righe, ncol = 1)

  for( i in 1 : righe){
    indici[i,] <- i
  }
  
  indici <- as.data.frame(indici)
  label_definitivo <- cbind(indici, manipolazione_distanza_data)
  
  indici_massimi <- matrix(0, nrow = flash, ncol = 1)
  
  k <- 1
  j <- 6
  
  for(i in 1:flash){
    temp <- label_definitivo[k:j,]
    max_index <- which.max(temp$`1`)
    indici_massimi[i,1] <- temp[max_index, 1]#cioè cosi seleziono l'elemento più grande della sestupla e memorizzo il suo indice (da 1 a 120)
    k <- k + 6
    j <- j + 6 
    
  }
  temp <- as.data.frame(temp)
  indici_massimi <- as.data.frame(indici_massimi)
  risultato <-test_prediction$predictions #è sempre il risultato che ottengo dalla SVM ma adesso devo seleionare i +1 massimi e mettere 
  #i +1 non massimi a -1
  
  for (i in 1:righe){
    risultato[i] <- -1
  }
  
  for(i in 1 : flash){
    j <- indici_massimi[i,1]
    risultato[j] <- 1
  }
  
  risultato <- as.data.frame(risultato)
  
  label_test <- YTS
  label_test <- as.data.frame(label_test)
  
  accuratezza_test <- test_accuratezza(risultato, label_test, parole) 
  
  return(accuratezza_test)
}